"""An interface to GraphViz."""

__author__ = "Ero Carrera"
__version__ = "2.0.0"
__license__ = "MIT"

from pydot.exceptions import *
from pydot.core import *
